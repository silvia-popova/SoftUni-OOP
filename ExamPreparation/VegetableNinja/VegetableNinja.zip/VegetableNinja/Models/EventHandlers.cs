﻿namespace VegetableNinja.Models
{
    using System;
    using Contracts;

    public delegate void OnMelolemonmelonEatenEventHandler(ICollisionHandler sender, EventArgs eventArgs);
}
