﻿namespace VegetableNinja.Models
{
    public class Broccoli : Vegetable
    {
        public Broccoli(int x, int y) 
            : base(x, y, "Broccoli", 'B', 10, 0, 3)
        {
        }
    }
}
