﻿namespace VegetableNinja.Contracts
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}
