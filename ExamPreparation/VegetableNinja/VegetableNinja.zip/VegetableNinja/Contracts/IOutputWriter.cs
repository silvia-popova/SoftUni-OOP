﻿namespace VegetableNinja.Contracts
{
    public interface IOutputWriter
    {
        void Write(string line);
    }
}
